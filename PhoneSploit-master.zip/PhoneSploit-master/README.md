# Recent News (New Update v.1.2)
Port Forwarding<br>        NetStat <br>
Grab wpa_supplicant <br>   Turn WiFi On/Off <br>                
Show Mac/Inet<br>          Remove Password<br>
Extract apk from app<br>   Use Keycode <br>           
Get Battery Status<br>     Get Current Activity<br>   

# PhoneSploit 
Using open Adb ports we can exploit a device
<br> you can find open ports here https://www.shodan.io/search?query=android+debug+bridge+product%3A”Android+Debug+Bridge”
<br>
<br> To find out how to access a local device --> https://www.youtube.com/watch?v=OlhCAX1qBQo


# HOW TO INSTALL WINDOWS
```
git clone https://github.com/Zucccs/PhoneSploit
extract adb.rar to the phonesploit directory 
cd PhoneSploit
pip install colorama
python2 main.py
```

# HOW TO INSTALL Linux
```
git clone https://github.com/Zucccs/PhoneSploit
cd PhoneSploit
pip install colorama
python2 main_linux.py
```
# IF ADB NOT FOUND
sudo apt update
sudo apt install android-tools-adb android-tools-fastboot



# VIDEO
[![Watch the video](https://img.youtube.com/vi/6XNf9s-PZxY/hqdefault.jpg)](https://www.youtube.com/watch?v=6XNf9s-PZxY)

# ScreenShots
![Screenshot](Screenshot.png)
